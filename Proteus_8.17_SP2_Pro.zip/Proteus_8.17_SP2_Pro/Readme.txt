Just instal it is preactivated.

+ Python works in Windows 7 (used in Arduino projects).
+ Deleted video codecs, as they were only needed for viewing video tutorials through the Proteus shell.
+ Deleted video encoding program, which probably got included in Proteus when the author was recording video tutorials.
+ Replaced the avr_tiny0series.dll file with the one from 8.16 SP0 (since the file from 8.17 SP2 has a critical error that causes Proteus to crash when simulating ATTINY202, ATTINY204, etc.).
+ Corrected gcc-arm.xml and stm32f1xx.h files for proper project creation on STM32F103C8.